  </main>
  <footer>
      <p>&copy; <?= date('Y') ?> CoteServ – Tous droits réservés.</p>
  </footer>
  </body>

  </html>